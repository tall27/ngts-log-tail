NGTS Log Tail - usage reporting build

Run ngts-log-tail.exe on Windows, or ./ngts-log-tail on macOS.
Use -version to identify the build. The release number ends in t.
macOS archives contain an unsigned command-line executable, not an installer.

60 seconds after a successful tenant activation, the app sends an encrypted
usage report to https://mypoc.mimlab.io/telemetry. The report contains tenant ID,
previous tenant ID, LAN IP, a random per-run ID, sequence, timestamps, version,
commit, and OS/architecture. The collector observes the source IP.
Credentials and activity logs are not included. Use -no-telemetry to disable.
The app remains usable if the collector is unavailable.
